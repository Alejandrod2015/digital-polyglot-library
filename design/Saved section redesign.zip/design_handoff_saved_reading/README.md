# Handoff: Saved Reading — "Shelf-first" reorder (Version 1A)

## Overview
Redesign of the **"Your saved reading"** screen (the `journey`/Library tab in the mobile app).
Today the screen leads with a **"Library snapshot"** stat grid, so the first thing the user
sees under a header that promises *your saved reading* is a block of numbers — the actual saved
stories are pushed below the fold. Version **1A** fixes this: the screen leads with the user's
**saved stories**, then their **saved books**, and the stats snapshot is removed entirely.

Rule the design enforces: **the first content shown is the saved stories if there are any; if
there are none, the saved books — whichever comes first.**

## About the Design Files
The file in this bundle (`Saved Reading.dc.html`) is a **design reference created in HTML** — a
prototype showing the intended look, order, and behavior. It is **not production code to copy
directly**.

The target codebase is the **existing React Native (Expo) mobile app** in this repo
(`apps/mobile`). The task is to **re-implement this layout inside that app** using its existing
components, styles, and data — specifically by reordering the `libraryView` in
`apps/mobile/src/mobile/MobileLibraryShell.tsx`. Do not introduce web/HTML; reuse the existing
React Native primitives and `StyleSheet` tokens already in that file.

## Fidelity
**High-fidelity (hifi).** Colors, typography, spacing, radii, and component structure are taken
directly from the existing app source, so the mock already matches the app's design system. The
implementer's job is mostly **reordering existing components and deleting the snapshot block** —
not restyling.

## Screen: Your saved reading (Library / `journey` tab)

### Purpose
Let the user immediately resume or open something they've already saved.

### Layout (top → bottom)
Vertical scroll (`ScrollView`, `styles.container`: `paddingHorizontal: 24`, `gap: 18`,
`paddingTop: 28`, `paddingBottom: 110`). Order:

1. **Hero** (`styles.hero`)
   - Eyebrow "SAVED" (`styles.eyebrow`), title "Your saved reading" (`styles.title`),
     subtitle (`styles.subtitle`). Right-aligned circular `MenuTrigger` (hamburger).
   - Suggested subtitle copy: *"Pick up any of your saved stories."* (optional; current copy
     "Saved, synced and ready to resume." also fine).
2. **Saved stories carousel** — section header eyebrow "SAVED STORIES" / title "Your reading
   shelf" / helper "N stories". Horizontal `ScrollView` of `BookHomeCard` (existing component,
   `width: 248`, landscape cover `height: 180`). This is the **existing `savedStoryCards` block**
   moved to the top. Keep its existing fallbacks: `savedStoryCards` → else `latestStoryCards`
   (suggested) → else empty state "No saved stories yet".
3. **Saved books carousel** — eyebrow "BOOKS" / title "Books in your library" / helper "N books".
   Horizontal `ScrollView` of `BookWebCard`. Existing `savedBooks` block, unchanged, moved up.
   Keep fallbacks: `savedBooks` → `remoteBookCards` → `latestBookCards` → empty state.

### What to REMOVE
- The entire **"Library snapshot"** card: `<View style={[styles.card, styles.accountCard,
  styles.librarySnapshotCard]}>` — the 2×2 `summaryGrid` tiles (Saved books / Saved stories /
  Synced stories / Offline ready), the weekly `helperText` line, the 2×2 `libraryMicroStats`
  grid (In motion / This week / Local / Synced), and the "Open favorites" inline link inside it.
- The "Open synced" / "Add more" mini-action buttons that lived in the snapshot header.
- Note: "Open favorites" (`setActiveScreen("favorites")`) currently only exists inside the
  snapshot card. If you still want a favorites entry point, keep the bottom-tab **Favorites** tab
  (already present) — no separate link needed on this screen.

### What to KEEP unchanged
- `continueReadingCards` "Continue reading" carousel, if present, stays as the top-most section
  above saved stories (it's the strongest "resume" signal). In the current mock this list is
  empty (In motion = 0) so nothing renders.
- `offlineReadyStoryCards` "Ready without internet" and any downstream sections — leave in place
  after books, or drop per product call.
- Bottom tab bar (`styles.bottomNav`) and status bar — unchanged. Active tab: **Journey**.

## Components (exact values, from `MobileLibraryShell.tsx` / `MobileCards.tsx`)

- **Hero eyebrow** (`eyebrow`): `#f8c15c`, 12px, weight 700, letter-spacing 1.6, uppercase.
- **Hero title** (`title`): `#f5f7fb`, 34px / lineHeight 38, weight 800.
- **Hero subtitle** (`subtitle`): `#b8c4d9`, 15px / lineHeight 22.
- **MenuTrigger** (`menuIconButton`): 44×44, radius 22, bg `#18304d`, border `#315174`,
  Feather `menu` icon 20px `#f5f7fb`.
- **Section header** (`sectionHeader`): row, `justify-content: space-between`, `align-items:
  flex-end`, gap 6. Eyebrow (`sectionEyebrow`): `#f8c15c`, 11px, weight 700, letter-spacing 1.2,
  uppercase. Title (`sectionTitle`): `#ffffff`, 20px, weight 700. Helper (`helperText`):
  `#9cb0c9`, 13px.
- **Carousel** (`carousel`): gap 12, `alignItems: flex-start`, `paddingRight: 12`.
- **BookHomeCard** (`bookHomeCard`): width 248, radius 24, border `#27405f`, bg `#14243b`,
  `overflow: hidden`. Cover (`bookHomeCardImage`) 100%×180, bg `#102238`. Body pad 14, gap 6.
  Title `#ffffff` 18/800 lineHeight 24; subtitle `#f8c15c` 14/700; meta `#aebcd3` 13;
  progress `#dbe9ff` 12/700.
- **BookWebCard** (`bookWebCard`): width 324, radius 20, border `#27405f`, bg `#14243b`, row,
  `align-items: flex-start`, pad 12, gap 12 (portrait cover thumbnail + text body).
- **Empty state** (`emptyCard`): bg `#14243b`, radius 22, border `#27405f`, pad 18, gap 8.
  Title (`emptyTitle`) `#ffffff` 18/700; body (`metaLine`) `#d6dfec` 15.
- **Offline badge** (from `favoriteSampleBadge`): bg `rgba(125,211,252,0.16)`, border
  `rgba(125,211,252,0.4)`, text `#7dd3fc` 9px/900, letter-spacing 1, radius 6, pad 3×7.

## Interactions & Behavior
- Tapping a story/book card → opens the reader/book detail (existing `item.onPress` handlers;
  reuse `openBook`, story open handlers already wired for these card arrays).
- No new animations. Horizontal carousels use the existing `decelerationRate="normal"`,
  `showsHorizontalScrollIndicator={false}`.
- Empty states are the existing ones; no new copy needed beyond what's listed.

## State Management
No new state. The design only **reorders existing render blocks** and removes the snapshot.
Data already available in the component: `savedStoryCards`, `latestStoryCards`, `savedBooks`,
`remoteBookCards`, `latestBookCards`, `continueReadingCards`, `offlineReadyStoryCards`,
`offlineSnapshot`, `remoteProgress`. The removed snapshot consumed
`savedBooks.length`, `savedStoryCards.length`, `remoteStoryCards.length`,
`offlineSnapshot?.stories.length`, `remoteProgress?.*` — those reads can be dropped from this view.

## Design Tokens (dark navy theme, from the app)
- Page background: `#0c1626` (app root, `App.tsx`)
- Card surface: `#14243b`; card border: `#27405f`; radius 28 (cards) / 24 / 20
- Elevated panel (was snapshot): `#18304d`
- Inner tile / stat surface: `#0f1f34` and `#102238`; tile border `#29435f`
- Accent (amber): `#f8c15c` — eyebrows, subtitles on cards, primary button bg
- Primary button text on amber: `#14243b`
- Ghost button: bg `#203754`, text `#dbe9ff`
- Text: primary `#f5f7fb`/`#ffffff`; secondary `#b8c4d9`/`#aebcd3`; muted `#9cb0c9`
- Link/cyan: `#7dd3fc`
- Bottom nav: bg `rgba(10,22,38,0.98)`, top border `#27405f`, active pill
  `rgba(31,79,134,0.28)`, inactive icon/label `#9cb0c9`, active `#ffffff`
- Font family: **Nunito** (`@expo-google-fonts/nunito`) — 400 / 700 / 800 / 900. See
  `apps/mobile/src/theme/tokens.ts`.

## Assets
- Story/book covers are remote images from the Sanity CDN
  (`https://cdn.sanity.io/images/9u7ilulp/production/...`), already used by the app's catalog
  (`apps/mobile/src/mobile/catalog.ts`, `src/data/books/*`). The HTML mock uses the same real
  cover URLs with `?w=&h=&fit=crop&auto=format` sizing params.
- Icons: Feather (`menu`, `bar-chart-2`, `star`) + MaterialCommunityIcons (`brain`) + the custom
  `JourneyIcon` SVG (`apps/mobile/src/mobile/JourneyIcon.tsx`). The HTML mock redraws these
  inline; in-app, keep using the existing icon components.

## Files
- `Saved Reading.dc.html` — the hifi design reference (this bundle). Open in a browser to see
  the target layout and copy.
- Source to edit in the repo: `apps/mobile/src/mobile/MobileLibraryShell.tsx` — the `libraryView`
  render (starts ~line 13188). Card components: `apps/mobile/src/mobile/MobileCards.tsx`.
